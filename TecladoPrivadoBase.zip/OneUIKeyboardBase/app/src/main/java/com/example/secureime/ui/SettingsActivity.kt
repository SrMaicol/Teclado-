package com.example.secureime.ui

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.example.secureime.data.VaultContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : ComponentActivity() {
    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) lifecycleScope.launch {
            // Decode or copy within this grant. Do not store a transient URI as permanent access.
            val header = withContext(Dispatchers.IO) {
                contentResolver.openInputStream(uri)?.use { input ->
                    val bytes = ByteArray(16)
                    val read = input.read(bytes)
                    if (read > 0) bytes.take(read).joinToString(" ") { "%02x".format(it) } else "vacío"
                }
            }
            findViewById<TextView>(100)?.text = "Imagen leída (${header ?: "sin datos"})"
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 32, 24, 24) }
        val status = TextView(this).apply { id = 100; text = "Teclado privado • Historial cifrado desde Android 6" }
        val entry = EditText(this).apply { hint = "Guardar clip manualmente"; maxLines = 2 }
        root.addView(status)
        root.addView(Button(this).apply { text = "Activar teclado"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        } })
        root.addView(Button(this).apply { text = "Elegir teclado"; setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        } })
        root.addView(entry)
        root.addView(Button(this).apply { text = "Guardar clip"; setOnClickListener {
            val text = entry.text.toString()
            if (text.isNotBlank()) lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching { contentResolver.insert(VaultContract.ITEMS, ContentValues().apply { put("text", text) }) }.isSuccess
                }
                status.text = if (ok) "Clip guardado" else "Historial no disponible"
                entry.text.clear()
            }
        } })
        root.addView(Button(this).apply { text = "Elegir imagen"; setOnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        } })
        setContentView(root)
    }
}
