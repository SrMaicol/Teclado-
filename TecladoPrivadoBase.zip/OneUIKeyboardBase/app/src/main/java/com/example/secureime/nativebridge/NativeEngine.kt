package com.example.secureime.nativebridge

object NativeEngine {
    init { System.loadLibrary("imecore") }
    external fun keyAt(x: Float, y: Float, width: Float, height: Float, numeric: Boolean): String
    external fun glide(indices: IntArray): String
    external fun twoFinger(dx: Float): Int // -1 undo, +1 redo, 0 no gesture
}
