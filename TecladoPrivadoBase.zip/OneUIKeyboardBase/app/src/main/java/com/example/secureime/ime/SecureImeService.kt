package com.example.secureime.ime

import android.content.res.Configuration
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.constraintlayout.motion.widget.MotionLayout
import com.example.secureime.R
import com.example.secureime.data.VaultContract
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SecureImeService : InputMethodService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var session = SupervisorJob()
    private var visibleWork: Job? = null
    private var policy = EditorPolicy.from(EditorInfo())
    private var root: MotionLayout? = null
    private var keys: KeyboardSurface? = null
    private var lastHaptic = 0L
    private var generation = 0L

    override fun onCreateInputView(): View = layoutInflater.inflate(R.layout.keyboard, null).also { view ->
        root = view as MotionLayout
        keys = view.findViewById<KeyboardSurface>(R.id.keys).apply {
            onKey = { token -> commit(token) }
            onAction = { performAction() }
            onFeedback = { haptic() }
        }
        view.findViewById<View>(R.id.hand).setOnClickListener {
            if (!policy.locked) view.transitionToState(if (view.currentState == R.id.one_hand) R.id.normal else R.id.one_hand)
        }
        view.findViewById<View>(R.id.tools).setOnClickListener {
            if (!policy.locked) loadClips()
        }
        view.findViewById<View>(R.id.emoji).setOnClickListener {
            if (!policy.locked) view.transitionToState(if (view.currentState == R.id.emoji_open) R.id.normal else R.id.emoji_open)
        }
        view.findViewById<android.widget.TextView>(R.id.panel).setOnClickListener {
            if (!policy.locked) commit("😀") // Replace with hit-tested emoji grid and Unicode data update.
        }
        applyPolicy()
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        generation++
        session.cancel()
        session = SupervisorJob(scope.coroutineContext[Job])
        policy = attribute?.let(EditorPolicy::from) ?: EditorPolicy.from(EditorInfo()).copy(locked = true, suppressSuggestions = true)
        // Do not request surrounding text, cache keystrokes, log input, or instantiate ML here.
        applyPolicy()
        if (policy.locked) {
            root?.transitionToState(R.id.normal)
            keys?.releaseVisuals()
        }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // A new view can be created after onStartInput; policy always belongs to the current editor.
        policy = info?.let(EditorPolicy::from) ?: policy
        applyPolicy()
        root?.transitionToState(R.id.normal)
    }

    private fun applyPolicy() {
        keys?.numeric = policy.numeric
        keys?.actionLabel = policy.actionLabel
        root?.findViewById<View>(R.id.tools)?.isEnabled = !policy.locked
        root?.findViewById<View>(R.id.emoji)?.isEnabled = !policy.locked
        root?.findViewById<View>(R.id.hand)?.isEnabled = !policy.locked
        root?.findViewById<android.widget.TextView>(R.id.status)?.text = if (policy.locked) "Modo seguro" else ""
    }

    private fun commit(token: String) {
        // InputConnection is accessed on the main thread. Never retain the token beyond this call.
        if (token == "⌫") currentInputConnection?.deleteSurroundingText(1, 0)
        else currentInputConnection?.commitText(token, 1)
    }
    private fun performAction() {
        val ic = currentInputConnection ?: return
        when (policy.action) {
            EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_SEARCH, EditorInfo.IME_ACTION_SEND,
            EditorInfo.IME_ACTION_NEXT, EditorInfo.IME_ACTION_DONE, EditorInfo.IME_ACTION_PREVIOUS -> ic.performEditorAction(policy.action)
            else -> ic.commitText("\n", 1)
        }
    }
    private fun loadClips() {
        val epoch = generation
        visibleWork?.cancel()
        visibleWork = scope.launch(session) {
            val text = withContext(Dispatchers.IO) {
                contentResolver.query(VaultContract.ITEMS, arrayOf("text"), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                }
            }
            val preview = withContext(Dispatchers.Default) { text?.let { "Clip disponible (${it.length} caracteres)" } }
            // Check the editor again after every suspension; a previous editor may now be a password field.
            withContext(Dispatchers.Main.immediate) {
                if (epoch == generation && !policy.locked && isInputViewShown && preview != null) {
                    root?.findViewById<android.widget.TextView>(R.id.status)?.text = preview
                    // An explicit UI selection is required before inserting clipboard content.
                }
            }
        }
    }
    private fun haptic() {
        val now = android.os.SystemClock.uptimeMillis()
        if (now - lastHaptic < 35) return
        lastHaptic = now
        if (Build.VERSION.SDK_INT >= 31) {
            val vibrator = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibrator.defaultVibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
        } else if (Build.VERSION.SDK_INT >= 29) {
            @Suppress("DEPRECATION") val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
        } else keys?.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
    }
    override fun onEvaluateFullscreenMode(): Boolean = false
    override fun onFinishInputView(finishingInput: Boolean) {
        stopVisibleWork()
        super.onFinishInputView(finishingInput)
    }
    override fun onWindowHidden() {
        stopVisibleWork()
        super.onWindowHidden()
    }
    private fun stopVisibleWork() {
        generation++
        visibleWork?.cancel()
        visibleWork = null
        keys?.releaseVisuals()
        root?.transitionToState(R.id.normal)
    }
    override fun onFinishInput() {
        session.cancel()
        super.onFinishInput()
    }
    override fun onDestroy() {
        stopVisibleWork()
        session.cancel()
        scope.cancel()
        keys = null
        root = null
        super.onDestroy()
    }
}
