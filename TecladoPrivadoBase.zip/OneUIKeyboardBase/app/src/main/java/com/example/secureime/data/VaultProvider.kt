package com.example.secureime.data

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.database.MatrixCursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Process
import android.provider.BaseColumns
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore

class VaultProvider : ContentProvider() {
    private lateinit var db: SQLiteOpenHelper
    private val matcher = UriMatcher(UriMatcher.NO_MATCH).apply { addURI(VaultContract.AUTHORITY, "items", 1) }
    override fun onCreate(): Boolean {
        db = object : SQLiteOpenHelper(context, "vault.db", null, 1) {
            override fun onCreate(db: SQLiteDatabase) {
                db.execSQL("CREATE TABLE items (_id INTEGER PRIMARY KEY AUTOINCREMENT, blob BLOB NOT NULL, created INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX items_created ON items(created DESC)")
            }
            override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
        }
        return true
    }
    private fun checkCaller(uri: Uri) {
        require(matcher.match(uri) == 1) { "Unknown URI" }
        if (Binder.getCallingUid() != Process.myUid()) throw SecurityException("App UID required")
        if (Build.VERSION.SDK_INT < 23) throw SecurityException("Encrypted history requires Android 6+")
    }
    override fun getType(uri: Uri): String { checkCaller(uri); return "vnd.android.cursor.dir/vnd.secureime.item" }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        checkCaller(uri)
        require(selection == null && selectionArgs == null && sortOrder == null)
        val columns = projection ?: arrayOf(BaseColumns._ID, "text")
        require(columns.all { it == BaseColumns._ID || it == "text" })
        val out = MatrixCursor(columns)
        db.readableDatabase.rawQuery("SELECT _id, blob FROM items ORDER BY created DESC LIMIT 20", null).use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                val decoded = try { decrypt(cursor.getBlob(1)) } catch (_: Exception) { continue }
                out.addRow(columns.map { if (it == "text") decoded else id })
            }
        }
        return out
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        checkCaller(uri)
        val value = values?.getAsString("text") ?: return null
        require(value.toByteArray(StandardCharsets.UTF_8).size <= 4096)
        val row = ContentValues().apply {
            put("blob", encrypt(value))
            put("created", System.currentTimeMillis())
        }
        val id = db.writableDatabase.insertOrThrow("items", null, row)
        db.writableDatabase.execSQL("DELETE FROM items WHERE _id NOT IN (SELECT _id FROM items ORDER BY created DESC LIMIT 20)")
        context?.contentResolver?.notifyChange(uri, null)
        return Uri.withAppendedPath(uri, id.toString())
    }
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int {
        checkCaller(uri)
        require(selection == null && selectionArgs == null)
        return db.writableDatabase.delete("items", null, null)
    }
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey("vault_aes", null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder("vault_aes", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build())
        return generator.generateKey()
    }
    private fun encrypt(text: String): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val bytes = cipher.doFinal(text.toByteArray(StandardCharsets.UTF_8))
        return ByteBuffer.allocate(1 + 12 + bytes.size).put(1.toByte()).put(cipher.iv).put(bytes).array()
    }
    private fun decrypt(blob: ByteArray): String {
        require(blob.size >= 29 && blob[0].toInt() == 1)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, blob.copyOfRange(1, 13)))
        return String(cipher.doFinal(blob.copyOfRange(13, blob.size)), StandardCharsets.UTF_8)
    }
}
