package com.example.secureime.ime

import android.text.InputType
import android.view.inputmethod.EditorInfo

internal data class EditorPolicy(
    val locked: Boolean,
    val suppressSuggestions: Boolean,
    val numeric: Boolean,
    val action: Int,
    val actionLabel: String
) {
    companion object {
        fun from(info: EditorInfo): EditorPolicy {
            val kind = info.inputType and InputType.TYPE_MASK_CLASS
            val variation = info.inputType and InputType.TYPE_MASK_VARIATION
            val password = (kind == InputType.TYPE_CLASS_TEXT && variation in setOf(
                InputType.TYPE_TEXT_VARIATION_PASSWORD,
                InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
                InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            )) || (kind == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
            val noLearn = info.imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING != 0
            val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
            val label = when (action) {
                EditorInfo.IME_ACTION_GO -> "Ir"
                EditorInfo.IME_ACTION_SEARCH -> "Buscar"
                EditorInfo.IME_ACTION_SEND -> "Enviar"
                EditorInfo.IME_ACTION_NEXT -> "Siguiente"
                EditorInfo.IME_ACTION_DONE -> "Listo"
                EditorInfo.IME_ACTION_PREVIOUS -> "Anterior"
                else -> "Enter"
            }
            return EditorPolicy(password, password || noLearn, kind == InputType.TYPE_CLASS_NUMBER ||
                kind == InputType.TYPE_CLASS_PHONE || kind == InputType.TYPE_CLASS_DATETIME, action, label)
        }
    }
}
