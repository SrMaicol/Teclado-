#include <jni.h>
#include <algorithm>
#include <cmath>
#include <string>

namespace {
constexpr const char* kRows[] = {"qwertyuiop", "asdfghjkl", "zxcvbnm"};
constexpr const char* kNums[] = {"123", "456", "789"};
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_secureime_nativebridge_NativeEngine_keyAt(JNIEnv* env, jobject, jfloat x, jfloat y,
                                                             jfloat width, jfloat height, jboolean numeric) {
    if (!std::isfinite(x) || !std::isfinite(y) || width <= 0 || height <= 0 ||
        x < 0 || y < 0 || x >= width || y >= height) return env->NewStringUTF("");
    const int row = std::clamp(static_cast<int>(y / height * 4), 0, 3);
    if (row == 3) return env->NewStringUTF(x < width * .23f ? "⌫" :
                                            x > width * .78f ? "↵" : " ");
    const char* chars = numeric ? kNums[row] : kRows[row];
    const int length = numeric ? 3 : static_cast<int>(std::char_traits<char>::length(chars));
    const int col = std::clamp(static_cast<int>(x / width * length), 0, length - 1);
    const char out[] = {chars[col], 0};
    return env->NewStringUTF(out);
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_secureime_nativebridge_NativeEngine_glide(JNIEnv* env, jobject, jintArray indices) {
    const jsize size = env->GetArrayLength(indices);
    if (size < 2 || size > 64) return env->NewStringUTF("");
    jint values[64];
    env->GetIntArrayRegion(indices, 0, size, values);
    std::string path;
    for (jsize i = 0; i < size; ++i) {
        const int idx = values[i];
        if (idx < 0 || idx >= 26) continue;
        const char c = static_cast<char>('a' + idx);
        if (path.empty() || path.back() != c) path.push_back(c);
    }
    // Geometric path only; a language model/dictionary candidate ranking is a separate module.
    return env->NewStringUTF(path.c_str());
}
extern "C" JNIEXPORT jint JNICALL
Java_com_example_secureime_nativebridge_NativeEngine_twoFinger(JNIEnv*, jobject, jfloat dx) {
    return dx < -90.f ? -1 : dx > 90.f ? 1 : 0;
}
