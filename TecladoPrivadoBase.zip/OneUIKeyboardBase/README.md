# Teclado privado: base Android API 21+

Proyecto de referencia Kotlin + JNI. Abrir la carpeta en Android Studio (JDK 17, SDK 35, NDK y CMake instalados), sincronizar Gradle y ejecutar `:app:assembleDebug`. El wrapper de Gradle no se incluye; Android Studio puede usar su instalación local de Gradle 8.9. Cambiar `applicationId`, autoridad del proveedor y `settingsActivity` juntos antes de distribuir.

## Arquitectura

- `SettingsActivity` (proceso principal): habilitar/elegir IME, guardar clips **manualmente**, Photo Picker.
- `SecureImeService` (`:ime`): proceso con UID de la app, ciclo de vida por editor y vista; no almacena pulsaciones ni solicita texto circundante.
- `VaultProvider` (`:vault`, `exported=false`): puente entre procesos con comprobación adicional de UID, SQLite con cifrado AES-256-GCM por fila y clave Android Keystore. Acceso a disco sólo mediante `Dispatchers.IO` desde clientes. El proveedor ejecuta su propio trabajo en hilos Binder, nunca desde la UI.
- `KeyboardSurface`: dibujo plano y toque síncrono; JNI sólo para geometría y gestos puros. AGSL únicamente en API 33+ con capa temporal; dibujo Canvas ligero en API 21–32.
- `MotionLayout`: estados normal, una mano y panel emoji. El hilo principal sigue participando en el cálculo de layout y en las actualizaciones de uniformes; no hay garantía de 16 ms o 120 fps sin medir en dispositivos reales.

## Privacidad y límites

`EditorPolicy` enmascara clase y variación del `inputType` para contraseñas de texto, visibles, web y numéricas; respeta también `IME_FLAG_NO_PERSONALIZED_LEARNING`. El modo bloqueado cancela la sesión anterior, impide abrir utilidades y emoji, no crea sugerencias ni traductor, y no guarda tokens. Un editor puede declarar mal su tipo, por lo que ninguna IME puede prometer privacidad absoluta. El teclado puede ver las teclas que el usuario escribe; el código evita registrar y transmitirlas. No hay permiso `INTERNET` ni `READ_CLIPBOARD`.

En API 21–22 el historial se desactiva porque este ejemplo usa claves AES-GCM en Android Keystore desde API 23. El teclado básico permanece disponible. Si el dispositivo está desbloqueado y la app/UID está comprometido, el cifrado en reposo no impide descifrar por el propio proceso. `android:allowBackup=false` evita copias de este almacén. No se usan WakeLocks. Parar animaciones y corrutinas visibles reduce actividad, pero Android y otros componentes impiden demostrar consumo exactamente cero.

`BIND_INPUT_METHOD` va como atributo `android:permission` del servicio exportado para que el sistema pueda enlazarlo. Declararlo como `<uses-permission>` sería incorrecto. Un servicio `android:isolatedProcess=true` tendría otro UID y no podría usar este proveedor interno tal cual: aquí el aislamiento son procesos privados separados bajo el mismo UID.

`THREAD_PRIORITY_BACKGROUND` reduce prioridad de trabajos que toleran demora; no fija afinidad LITTLE y sería perjudicial para el camino táctil. El planificador decide el núcleo. Para perfilar, usar trazas de Perfetto/ADPF y medir latencia, fotogramas y energía por dispositivo. AGSL usa GPU donde Android ofrece aceleración, pero el paso de eventos, Animator y composición no deja la CPU completamente libre.

Google ML Kit Translation requiere API 23 y descarga inicial de modelos; su API pública no ofrece un switch que garantice NNAPI/NPU. Este proyecto deja traducción sin activar para no introducir descarga o procesado de texto implícito. Una función futura debería requerir consentimiento expreso, descarga visible y control del ciclo de vida; para elegir delegados de NNAPI/GPU se necesita un modelo propio TFLite compatible y verificar disponibilidad por dispositivo. No conviene prometer ahorro energético sin medición.

El panel emoji es una muestra con glifos del sistema, no un catálogo Unicode completo ni arte iOS. Las imágenes del Photo Picker se leen durante la concesión temporal, sin guardar el URI. El motor JNI contiene mapa táctil y extracción de ruta; aún faltan diccionario de candidatos de deslizamiento, undo/redo real, macros, accesibilidad, localización, cambio de idioma, gestión de portapapeles con selección explícita y pruebas de integración de IME. Nunca procesar contraseñas con esos módulos cuando se implementen.

## Pruebas de aceptación antes de producción

En dispositivos API 21, 23, 29, 33 y 35: alternar rápidamente un campo normal y uno de contraseña mientras una consulta IO está pendiente; comprobar que no reaparece un clip. Probar los cuatro tipos de contraseña, `IME_FLAG_NO_PERSONALIZED_LEARNING`, acciones IME, rotación, ocultar ventana, fallos de Keystore, entrada numérica y eliminación Unicode por grafemas. Medir `frameTiming`, cold start, consumo y memoria con trazas; instrumentar pruebas reales de IME. Este es un punto de partida, no un producto certificado de misión crítica.
