package com.example.secureime.ime

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.example.secureime.nativebridge.NativeEngine
import kotlin.math.min

class KeyboardSurface(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    var onKey: ((String) -> Unit)? = null
    var onAction: (() -> Unit)? = null
    var onFeedback: (() -> Unit)? = null
    var numeric = false
        set(value) { field = value; invalidate() }
    var actionLabel = "Enter"
        set(value) { field = value; invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spring = SpringAnimation(this, SCALE_X, 1f).apply {
        spring = SpringForce(1f).apply { stiffness = 420f; dampingRatio = .72f }
    }
    private var ripple: ValueAnimator? = null
    private var shader: RuntimeShader? = null
    private var downX = 0f
    private var downY = 0f
    private var pointerCountAtDown = 1

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val rows = if (numeric) arrayOf("123", "456", "789") else arrayOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        val h = height / 4f
        rows.forEachIndexed { row, letters ->
            val w = width / letters.length.toFloat()
            letters.forEachIndexed { col, char ->
                val left = col * w + 2f
                val top = row * h + 2f
                paint.color = Color.WHITE
                canvas.drawRoundRect(RectF(left, top, (col + 1) * w - 2f, (row + 1) * h - 2f), 12f, 12f, paint)
                paint.color = Color.rgb(31, 35, 49)
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = min(h * .4f, 26f * resources.displayMetrics.scaledDensity)
                canvas.drawText(char.toString(), left + (w - 4f) / 2, top + h * .61f, paint)
            }
        }
        val bottom = arrayOf("⌫", "espacio", actionLabel)
        val edges = floatArrayOf(0f, width * .23f, width * .78f, width.toFloat())
        bottom.forEachIndexed { i, label ->
            paint.color = Color.WHITE
            canvas.drawRoundRect(RectF(edges[i] + 2, 3 * h + 2, edges[i + 1] - 2, 4 * h - 2), 12f, 12f, paint)
            paint.color = Color.rgb(31, 35, 49)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 16f * resources.displayMetrics.scaledDensity
            canvas.drawText(label, (edges[i] + edges[i + 1]) / 2, 3.6f * h, paint)
        }
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y; pointerCountAtDown = 1
                spring.cancel(); scaleX = .985f; spring.animateToFinalPosition(1f)
                showRipple(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> { pointerCountAtDown = 2; return true }
            MotionEvent.ACTION_UP -> {
                if (pointerCountAtDown == 2) {
                    val gesture = NativeEngine.twoFinger(event.x - downX)
                    if (gesture != 0) onFeedback?.invoke() // Undo/redo requires an explicit editor-safe implementation.
                } else if (kotlin.math.abs(event.x - downX) < 32f && kotlin.math.abs(event.y - downY) < 32f) {
                    when (val token = NativeEngine.keyAt(event.x, event.y, width.toFloat(), height.toFloat(), numeric)) {
                        "↵" -> onAction?.invoke()
                        "⌫" -> onKey?.invoke("⌫")
                        "" -> Unit
                        else -> onKey?.invoke(token)
                    }
                    onFeedback?.invoke()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> { releaseVisuals(); return true }
        }
        return true
    }
    private fun showRipple(x: Float, y: Float) {
        if (Build.VERSION.SDK_INT < 33 || !isHardwareAccelerated) return
        ripple?.cancel()
        val effect = shader ?: RuntimeShader("""
            uniform shader inputImage;
            uniform float2 center;
            uniform float radius;
            half4 main(float2 p) {
                half4 base = inputImage.eval(p);
                float d = distance(p, center);
                float ring = exp(-pow((d - radius) / 18.0, 2.0)) * (1.0 - radius / 460.0);
                return half4(min(base.rgb + half3(0.08, 0.18, 0.32) * half(max(ring, 0.0)), half3(1.0)), base.a);
            }
        """.trimIndent()).also { shader = it }
        effect.setFloatUniform("center", x, y)
        setLayerType(LAYER_TYPE_HARDWARE, null)
        setRenderEffect(RenderEffect.createRuntimeShaderEffect(effect, "inputImage"))
        ripple = ValueAnimator.ofFloat(0f, 300f).apply {
            duration = 240
            addUpdateListener { effect.setFloatUniform("radius", it.animatedValue as Float); invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { clearEffect() }
            })
            start()
        }
    }
    private fun clearEffect() {
        if (Build.VERSION.SDK_INT >= 31) setRenderEffect(null)
        setLayerType(LAYER_TYPE_NONE, null)
    }
    fun releaseVisuals() {
        ripple?.cancel(); ripple = null
        spring.cancel(); scaleX = 1f
        clearEffect(); shader = null
    }
}
