package com.example.secureime.data

import android.net.Uri

object VaultContract {
    const val AUTHORITY = "com.example.secureime.vault"
    val ITEMS: Uri = Uri.parse("content://$AUTHORITY/items")
}
